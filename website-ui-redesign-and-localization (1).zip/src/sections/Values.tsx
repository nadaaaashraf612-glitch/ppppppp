"use client";

import { motion } from "framer-motion";
import { Reveal } from "../components/Reveal";
import { BlurShapes } from "../components/BlurShapes";
import { GlowOrb, Kicker, PageMeta } from "../components/ui";
import { ValueArt } from "../components/ValueArt";
import { useLanguage } from "../i18n/LanguageContext";

// bento: three on the first row, two wider ones beneath
const spans = ["lg:col-span-2", "lg:col-span-2", "lg:col-span-2", "lg:col-span-3", "lg:col-span-3"];

export function Values() {
  const { t } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "values");

  return (
    <section id="values" className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-[#fafaf8] px-6 py-28 sm:px-10 lg:px-16 isolate">
      <BlurShapes tone="light" seed={16} />
      <GlowOrb className="end-0 bottom-10 h-80 w-80" />

      <Reveal>
        <Kicker>{t.values.kicker}</Kicker>
        <h2 className="mt-8 max-w-2xl font-display text-5xl font-semibold leading-tight tracking-tight sm:text-6xl">
          {t.values.heading}
        </h2>
      </Reveal>

      <div className="relative z-10 mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-6">
        {t.values.items.map((item, i) => (
          <Reveal key={item.title} delay={i * 90} className={`${spans[i % spans.length]} ${i === 4 ? "sm:col-span-2" : ""}`}>
            <motion.article
              whileHover={{ y: -6 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="group relative flex h-full flex-col overflow-hidden rounded-[2rem] bg-black text-white shadow-[0_30px_70px_-40px_rgba(0,0,0,0.6)]"
            >
              {/* illustration stage */}
              <div
                className="relative flex h-44 items-center justify-center overflow-hidden"
                style={{
                  background:
                    "radial-gradient(70% 90% at 50% 55%, rgba(255,255,255,0.12), transparent 70%), linear-gradient(180deg, #111, #050505)",
                }}
              >
                <span className="absolute start-6 top-5 font-display text-xs tabular-nums text-white/35" dir="ltr">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <ValueArt
                  index={i}
                  className="h-full w-full max-w-[280px] transition-transform duration-700 ease-out group-hover:scale-110"
                />
              </div>

              <div className="flex flex-1 flex-col p-6 sm:p-7">
                <h3 className="font-display text-xl font-semibold tracking-tight sm:text-2xl">{item.title}</h3>
                <p className="mt-3 max-w-xl text-sm leading-relaxed text-white/65 sm:text-base">{item.copy}</p>
              </div>
            </motion.article>
          </Reveal>
        ))}
      </div>

      <PageMeta index={String(idx + 1).padStart(2, "0")} label={t.sectionIndex[idx].label} />
    </section>
  );
}
