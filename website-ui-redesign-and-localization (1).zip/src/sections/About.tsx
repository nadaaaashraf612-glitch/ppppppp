"use client";

import { motion } from "framer-motion";
import { BlurShapes } from "../components/BlurShapes";
import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta } from "../components/ui";
import { AboutGlass } from "../components/glass/AboutGlass";
import { useLanguage } from "../i18n/LanguageContext";

export function About() {
  const { t } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "about");

  return (
    <section
      id="about"
      className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-[#fafaf8] px-6 py-28 isolate sm:px-10 lg:px-16"
    >
      <BlurShapes tone="light" seed={0} />

      <div className="relative z-10 grid grid-cols-1 items-center gap-8 lg:grid-cols-[minmax(0,0.95fr)_minmax(0,1.05fr)] lg:gap-10">
        {/* Black-glass illustration: a cradle that holds, then lifts, an idea */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="relative mx-auto aspect-square w-full max-w-[560px] lg:sticky lg:top-24"
        >
          <AboutGlass className="absolute inset-0" />
        </motion.div>

        <Reveal delay={100}>
          <Kicker>{t.about.kicker}</Kicker>
          <h2 className="mt-8 font-display text-5xl font-semibold leading-tight tracking-tight sm:text-6xl">
            {t.about.heading}
          </h2>
          <div className="mt-8 flex flex-col gap-6">
            {t.about.paragraphs.map((p, i) => (
              <Reveal key={i} delay={160 + i * 100}>
                <p className="max-w-2xl text-base leading-relaxed text-black/75 sm:text-lg">{p}</p>
              </Reveal>
            ))}
          </div>
        </Reveal>
      </div>

      <PageMeta index={String(idx + 1).padStart(2, "0")} label={t.sectionIndex[idx].label} />
    </section>
  );
}
