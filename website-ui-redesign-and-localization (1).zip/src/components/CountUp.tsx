"use client";

import { useEffect, useRef, useState } from "react";
import { animate, useInView } from "framer-motion";

/** Counts a value like "+3,000", "+50", "2016" up from zero once it scrolls into view. */
export function CountUp({ value, duration = 2.2, className }: { value: string; duration?: number; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.6 });

  const m = value.match(/^(\D*)([\d,.]+)(\D*)$/);
  const prefix = m?.[1] ?? "";
  const raw = m?.[2] ?? "";
  const suffix = m?.[3] ?? "";
  const target = parseFloat(raw.replace(/,/g, ""));
  const grouped = raw.includes(",");
  const isYear = !grouped && target >= 1900 && target <= 2100;
  const from = isYear ? target - 40 : 0;

  const fmt = (n: number) => {
    const r = Math.round(n);
    return grouped ? r.toLocaleString("en-US") : String(r);
  };
  const [text, setText] = useState(m ? fmt(from) : value);

  useEffect(() => {
    if (!inView || !m) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setText(fmt(target));
      return;
    }
    const c = animate(from, target, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => setText(fmt(v)),
    });
    return () => c.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inView]);

  if (!m) return <span className={className}>{value}</span>;
  return (
    <span ref={ref} className={className} dir="ltr" style={{ display: "inline-block", fontVariantNumeric: "tabular-nums" }}>
      {prefix}
      {text}
      {suffix}
    </span>
  );
}
