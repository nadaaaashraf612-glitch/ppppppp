// Projects pulled from https://puiux.com/work/ — 82 featured case studies + 44 more sites.
// Cover images are the official hosted covers from puiux.com.
export type WorkGroup = "شركات وخدمات" | "تجارة إلكترونية" | "عقارات وبناء" | "صناعة وتصدير" | "تعليم" | "تطبيقات" | "صحة ومجتمع" | "قانون";

export interface Work {
  slug: string;
  titleAr: string;
  titleEn: string;
  group: WorkGroup;
  sectorAr: string;
  descAr: string;
  accent: string;
  /** public domain label shown in the browser bar (null for mobile apps) */
  domain: string | null;
  /** case-study page on puiux.com */
  caseUrl: string;
  /** website cover (1280×800) */
  cover: string | null;
  /** phone screenshots for app projects */
  phones: string[] | null;
  alt: string | null;
}

export interface ArchiveWork {
  titleAr: string;
  titleEn: string;
  sectorAr: string;
  sectorEn: string;
  cover: string;
}

export const WORK_URL = "https://puiux.com/work/";

export const groupLabels: Record<WorkGroup, { ar: string; en: string }> = {
  "شركات وخدمات": {
    "ar": "شركات وخدمات",
    "en": "Corporate & Services"
  },
  "تجارة إلكترونية": {
    "ar": "تجارة إلكترونية",
    "en": "E-commerce"
  },
  "عقارات وبناء": {
    "ar": "عقارات وبناء",
    "en": "Real Estate & Construction"
  },
  "صناعة وتصدير": {
    "ar": "صناعة وتصدير",
    "en": "Industry & Export"
  },
  "تعليم": {
    "ar": "تعليم",
    "en": "Education"
  },
  "تطبيقات": {
    "ar": "تطبيقات",
    "en": "Apps"
  },
  "صحة ومجتمع": {
    "ar": "صحة ومجتمع",
    "en": "Health & Community"
  },
  "قانون": {
    "ar": "قانون",
    "en": "Legal"
  }
};

export const works: Work[] = [
 {
  "slug": "samt",
  "titleAr": "سَمْت",
  "titleEn": "Samt",
  "group": "شركات وخدمات",
  "sectorAr": "الطيران الخاص",
  "descAr": "موقع يعمل كأجهزة الملاحة: هادئ، ودقيق، ويخبرك أين أنت.",
  "accent": "#F6A04A",
  "domain": "samt.puiux.org",
  "caseUrl": "https://puiux.com/work/samt/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/samt-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع سَمْت"
 },
 {
  "slug": "nadd",
  "titleAr": "نَدّ",
  "titleEn": "Nadd",
  "group": "تجارة إلكترونية",
  "sectorAr": "العود والعطور",
  "descAr": "متجر عطور يفتح كل صفحاته من الدخان والجمر.",
  "accent": "#D59C62",
  "domain": "nadd.puiux.org",
  "caseUrl": "https://puiux.com/work/nadd/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/nadd-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع نَدّ"
 },
 {
  "slug": "ghasaq",
  "titleAr": "غسق",
  "titleEn": "Ghasaq",
  "group": "شركات وخدمات",
  "sectorAr": "الضيافة والمنتجعات",
  "descAr": "صفحة واحدة هي أمسية كاملة، من الرابعة والنصف حتى منتصف الليل.",
  "accent": "#B5532C",
  "domain": "ghasaq.puiux.org",
  "caseUrl": "https://puiux.com/work/ghasaq/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/ghasaq-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع غسق"
 },
 {
  "slug": "mizwala",
  "titleAr": "مِزْوَلة",
  "titleEn": "Mizwala",
  "group": "عقارات وبناء",
  "sectorAr": "العمارة والتصميم الداخلي",
  "descAr": "عمارة تُقاس بالظل، وموقع يتحرك مثل ظل المِزْوَلة.",
  "accent": "#B5532C",
  "domain": "mizwala.puiux.org",
  "caseUrl": "https://puiux.com/work/mizwala/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/mizwala-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع مِزْوَلة"
 },
 {
  "slug": "kashida",
  "titleAr": "كشيدة",
  "titleEn": "Kashida",
  "group": "شركات وخدمات",
  "sectorAr": "الفنون والتصميم",
  "descAr": "الحرف يمتد، والخط يكمل طريقه في كل صفحة.",
  "accent": "#3346C8",
  "domain": "kashida.puiux.org",
  "caseUrl": "https://puiux.com/work/kashida/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/kashida-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع كشيدة"
 },
 {
  "slug": "wadeea",
  "titleAr": "وديعة",
  "titleEn": "Wadeea",
  "group": "صناعة وتصدير",
  "sectorAr": "الطاقة وتخزين الكهرباء",
  "descAr": "شمس النهار محفوظة لليل، وكل صفحة ساعة من الليلة نفسها.",
  "accent": "#D0A04A",
  "domain": "wadeea.puiux.org",
  "caseUrl": "https://puiux.com/work/wadeea/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/wadeea-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع وديعة"
 },
 {
  "slug": "ghars",
  "titleAr": "غرس",
  "titleEn": "Ghars",
  "group": "شركات وخدمات",
  "sectorAr": "الادخار والاستثمار",
  "descAr": "ازرع ريالًا، واحصد هدفًا.",
  "accent": "#E2683F",
  "domain": "ghars.puiux.org",
  "caseUrl": "https://puiux.com/work/ghars/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/ghars-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع غرس"
 },
 {
  "slug": "sufuh",
  "titleAr": "سُفوح",
  "titleEn": "Sufuh",
  "group": "عقارات وبناء",
  "sectorAr": "المساحة والدراسات الميدانية",
  "descAr": "موقع مرسوم مثل ورقة عمل ميدانية.",
  "accent": "#2F5A3C",
  "domain": "sufuh.puiux.org",
  "caseUrl": "https://puiux.com/work/sufuh/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/sufuh-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع سُفوح"
 },
 {
  "slug": "mabani",
  "titleAr": "مباني الجزيرة العربية للمشاريع",
  "titleEn": "Arabian Peninsula Buildings for Projects",
  "group": "عقارات وبناء",
  "sectorAr": "تصميم وبناء ومقاولات",
  "descAr": "حضور رقمي بحجم المشاريع التي تبنيها.",
  "accent": "#fe9b31",
  "domain": "mabani.com.sa",
  "caseUrl": "https://puiux.com/work/mabani/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/mabani-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع مباني الجزيرة العربية للمشاريع"
 },
 {
  "slug": "seu",
  "titleAr": "الجامعة السعودية الإلكترونية",
  "titleEn": "Saudi Electronic University",
  "group": "تعليم",
  "sectorAr": "التعليم العالي",
  "descAr": "جامعة بحجم المملكة، في واجهة واحدة واضحة.",
  "accent": "#09256e",
  "domain": "seu.puiux.org",
  "caseUrl": "https://puiux.com/work/seu/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/seu-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع الجامعة السعودية الإلكترونية"
 },
 {
  "slug": "gtel",
  "titleAr": "ملتقى جي تيل",
  "titleEn": "GTEL Forum",
  "group": "تعليم",
  "sectorAr": "المؤتمرات والتعليم الإلكتروني",
  "descAr": "ملتقى دولي، بحقائقه وأرقامه في صفحة واحدة.",
  "accent": "#2d99bc",
  "domain": "gtel.puiux.org",
  "caseUrl": "https://puiux.com/work/gtel/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/gtel-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع ملتقى GTEL"
 },
 {
  "slug": "swan-missan",
  "titleAr": "سوان وميسان",
  "titleEn": "Swan & Missan",
  "group": "عقارات وبناء",
  "sectorAr": "تطوير عقاري",
  "descAr": "فخامة المعمار، في تجربة رقمية هادئة.",
  "accent": "#453020",
  "domain": "swanmissan.sa",
  "caseUrl": "https://puiux.com/work/swan-missan/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/swan-missan-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع سوان وميسان"
 },
 {
  "slug": "othaim-developments",
  "titleAr": "العثيم للتطوير",
  "titleEn": "Al-Othaim Developments",
  "group": "عقارات وبناء",
  "sectorAr": "تطوير عقاري سكني",
  "descAr": "من الإعجاب بالمشروع إلى تسجيل الاهتمام في خطوة.",
  "accent": "#2d213e",
  "domain": "othaimdevelopments.com",
  "caseUrl": "https://puiux.com/work/othaim-developments/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/othaim-developments-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع العثيم للتطوير"
 },
 {
  "slug": "seem-prime",
  "titleAr": "سيم برايم",
  "titleEn": "Seem Prime",
  "group": "شركات وخدمات",
  "sectorAr": "استثمار وتشغيل منصات أعمال",
  "descAr": "منظومة من تسعة قطاعات، تُفهم من أول شاشة.",
  "accent": "#472f1d",
  "domain": "seem.sa",
  "caseUrl": "https://puiux.com/work/seem-prime/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/seem-prime-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع سيم برايم"
 },
 {
  "slug": "skys",
  "titleAr": "سكايز",
  "titleEn": "SKYS",
  "group": "تطبيقات",
  "sectorAr": "سفر وسياحة",
  "descAr": "من البحث إلى الحجز والدفع، في تطبيق واحد.",
  "accent": "#3b5bdb",
  "domain": null,
  "caseUrl": "https://puiux.com/work/skys/",
  "cover": null,
  "phones": [
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/skys-2.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/skys-1.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/skys-3.webp"
  ],
  "alt": null
 },
 {
  "slug": "coach-me",
  "titleAr": "كوتش مي",
  "titleEn": "Coach Me",
  "group": "تطبيقات",
  "sectorAr": "رياضة ولياقة",
  "descAr": "المدرب المناسب، قريب منك، بحجز واحد.",
  "accent": "#c6f432",
  "domain": null,
  "caseUrl": "https://puiux.com/work/coach-me/",
  "cover": null,
  "phones": [
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/coach-2.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/coach-1.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/coach-3.webp"
  ],
  "alt": null
 },
 {
  "slug": "origin-coffee",
  "titleAr": "أوريجن كوفي",
  "titleEn": "Origin Coffee",
  "group": "تطبيقات",
  "sectorAr": "قهوة مختصة",
  "descAr": "عالم القهوة المختصة كله في جيبك.",
  "accent": "#b07a4f",
  "domain": null,
  "caseUrl": "https://puiux.com/work/origin-coffee/",
  "cover": null,
  "phones": [
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/origin-3.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/origin-2.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/origin-4.webp"
  ],
  "alt": null
 },
 {
  "slug": "sufoof",
  "titleAr": "صفوف",
  "titleEn": "Sfoof",
  "group": "تطبيقات",
  "sectorAr": "ترفيه وتراث",
  "descAr": "الملعبة الشعبية، بصوت الذكاء الاصطناعي.",
  "accent": "#e0b23a",
  "domain": null,
  "caseUrl": "https://puiux.com/work/sufoof/",
  "cover": null,
  "phones": [
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/sufoof-4.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/sufoof-3.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/sufoof-1.webp"
  ],
  "alt": null
 },
 {
  "slug": "gobite",
  "titleAr": "جو بايت",
  "titleEn": "GoBite",
  "group": "تطبيقات",
  "sectorAr": "طلب واستلام الطعام",
  "descAr": "اطلب قبل أن تصل، واستلم دون انتظار.",
  "accent": "#ff8a1f",
  "domain": null,
  "caseUrl": "https://puiux.com/work/gobite/",
  "cover": null,
  "phones": [
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/gobite-3.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/gobite-2.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/gobite-4.webp"
  ],
  "alt": null
 },
 {
  "slug": "yusr",
  "titleAr": "يُسر",
  "titleEn": "Yusr",
  "group": "تطبيقات",
  "sectorAr": "خدمة الحجاج والمعتمرين",
  "descAr": "مساعدة ضيوف الرحمن بلمسة واحدة.",
  "accent": "#c9a36a",
  "domain": null,
  "caseUrl": "https://puiux.com/work/yusr/",
  "cover": null,
  "phones": [
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/yusr-3.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/yusr-2.webp",
   "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/apps/yusr-4.webp"
  ],
  "alt": null
 },
 {
  "slug": "dalamin",
  "titleAr": "دلامين",
  "titleEn": "Dalamin",
  "group": "تجارة إلكترونية",
  "sectorAr": "أزياء وعبايات",
  "descAr": "متجر عبايات يُتصفح كمجلة أزياء.",
  "accent": "#b78852",
  "domain": "dalamin.com",
  "caseUrl": "https://puiux.com/work/dalamin/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/dalamin-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع دلامين"
 },
 {
  "slug": "elan-flowers",
  "titleAr": "إيلان للزهور",
  "titleEn": "Elan Flowers",
  "group": "تجارة إلكترونية",
  "sectorAr": "زهور وهدايا",
  "descAr": "متجر زهور يجعل اختيار الهدية متعة.",
  "accent": "#7e7ab9",
  "domain": "elanflowers.sa",
  "caseUrl": "https://puiux.com/work/elan-flowers/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/elan-flowers-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع إيلان للزهور"
 },
 {
  "slug": "health-community",
  "titleAr": "مجتمع الصحة",
  "titleEn": "Health Community",
  "group": "صحة ومجتمع",
  "sectorAr": "توظيف وتدريب في القطاع الصحي",
  "descAr": "منصة واحدة لوظائف القطاع الصحي ودوراته.",
  "accent": "#076b60",
  "domain": "healthcommunity.sa",
  "caseUrl": "https://puiux.com/work/health-community/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/health-community-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع مجتمع الصحة"
 },
 {
  "slug": "glex",
  "titleAr": "غلوبال إكسبورت هاوس",
  "titleEn": "Global Export House",
  "group": "صناعة وتصدير",
  "sectorAr": "تصدير وخدمات لوجستية",
  "descAr": "بوابة تصدير تخاطب العملاء داخل المملكة وخارجها.",
  "accent": "#6fa9bd",
  "domain": "exporthouse.com.sa",
  "caseUrl": "https://puiux.com/work/glex/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/glex-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع غلوبال إكسبورت هاوس"
 },
 {
  "slug": "naht",
  "titleAr": "نحت العقارية",
  "titleEn": "Naht Real Estate",
  "group": "عقارات وبناء",
  "sectorAr": "تطوير عقاري",
  "descAr": "مشاريع عقارية تُعرض كما تستحق.",
  "accent": "#94b1d3",
  "domain": "naht-re.sa",
  "caseUrl": "https://puiux.com/work/naht/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/naht-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع نحت العقارية"
 },
 {
  "slug": "alrashdi-law",
  "titleAr": "تركي الراشدي للمحاماة والاستشارات القانونية",
  "titleEn": "Turki Al-Rashdi Law & Legal Consultancy",
  "group": "قانون",
  "sectorAr": "محاماة واستشارات قانونية",
  "descAr": "مكتب محاماة بهوية رقمية جريئة ومختلفة.",
  "accent": "#0e465e",
  "domain": "alrashdilawfirm.com",
  "caseUrl": "https://puiux.com/work/alrashdi-law/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/alrashdi-law-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع تركي الراشدي للمحاماة والاستشارات القانونية"
 },
 {
  "slug": "nawan",
  "titleAr": "ناوان",
  "titleEn": "Nawan",
  "group": "شركات وخدمات",
  "sectorAr": "منصات رقمية وخدمات تسويق",
  "descAr": "سوق يجمع العلامات التجارية بوكالات التسويق.",
  "accent": "#f90059",
  "domain": "nawan.co",
  "caseUrl": "https://puiux.com/work/nawan/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/nawan-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع ناوان"
 },
 {
  "slug": "sariah",
  "titleAr": "سارية",
  "titleEn": "Sariah",
  "group": "شركات وخدمات",
  "sectorAr": "حاضنات الأعمال",
  "descAr": "بوابة واحدة لكل ما يحتاجه رائد الأعمال",
  "accent": "#475e78",
  "domain": "sariah.sa",
  "caseUrl": "https://puiux.com/work/sariah/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/sariah-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع سارية"
 },
 {
  "slug": "star8",
  "titleAr": "ستار 8",
  "titleEn": "Star 8",
  "group": "شركات وخدمات",
  "sectorAr": "الإعلام والعلاقات العامة",
  "descAr": "من الفكرة إلى طلب الخدمة في صفحة واحدة",
  "accent": "#c656a0",
  "domain": "star8.sa",
  "caseUrl": "https://puiux.com/work/star8/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/star8-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع ستار 8"
 },
 {
  "slug": "awtada",
  "titleAr": "أوتادا العقارية",
  "titleEn": "Awtada Real Estate",
  "group": "شركات وخدمات",
  "sectorAr": "التطوير العقاري",
  "descAr": "وحدات واضحة المواصفات تقود إلى قرار التملك",
  "accent": "#83572d",
  "domain": "awtada.sa",
  "caseUrl": "https://puiux.com/work/awtada/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/awtada-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع أوتادا العقارية"
 },
 {
  "slug": "falawyer",
  "titleAr": "شركة فاطمة علي عسيري للمحاماة",
  "titleEn": "Fatima Ali Asiri Law Firm",
  "group": "قانون",
  "sectorAr": "المحاماة والاستشارات القانونية",
  "descAr": "ثقة قانونية تبدأ قبل أول استشارة",
  "accent": "#154d27",
  "domain": "falawyer.sa",
  "caseUrl": "https://puiux.com/work/falawyer/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/falawyer-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع شركة فاطمة علي عسيري للمحاماة"
 },
 {
  "slug": "rosokh",
  "titleAr": "رسوخ",
  "titleEn": "Rosokh",
  "group": "شركات وخدمات",
  "sectorAr": "القطاع غير الربحي",
  "descAr": "شفافية تبني الثقة مع الداعمين والمجتمع",
  "accent": "#d0a962",
  "domain": "rosokh.org.sa",
  "caseUrl": "https://puiux.com/work/rosokh/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/rosokh-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع رسوخ"
 },
 {
  "slug": "pfa",
  "titleAr": "جمعية أصدقاء المرضى",
  "titleEn": "Patients' Friends Association",
  "group": "شركات وخدمات",
  "sectorAr": "القطاع غير الربحي",
  "descAr": "تبرع أسهل يصل إلى المرضى المحتاجين.",
  "accent": "#085154",
  "domain": "pfa.com.sa",
  "caseUrl": "https://puiux.com/work/pfa/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/pfa-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع جمعية أصدقاء المرضى"
 },
 {
  "slug": "statix-sa",
  "titleAr": "ستاتيكس",
  "titleEn": "Statix",
  "group": "شركات وخدمات",
  "sectorAr": "الخدمات المالية والمحاسبية",
  "descAr": "قرارات مالية أوضح لكل منشأة.",
  "accent": "#1b2e45",
  "domain": "statix-sa.com",
  "caseUrl": "https://puiux.com/work/statix-sa/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/statix-sa-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع ستاتيكس"
 },
 {
  "slug": "gbcest",
  "titleAr": "الجسر الأخضر للمقاولات",
  "titleEn": "Green Bridge Contracting",
  "group": "عقارات وبناء",
  "sectorAr": "تنسيق الحدائق والمقاولات",
  "descAr": "حدائق فاخرة تبقى بأجمل صورها.",
  "accent": "#830022",
  "domain": "gbcest.com",
  "caseUrl": "https://puiux.com/work/gbcest/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/gbcest-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع الجسر الأخضر للمقاولات"
 },
 {
  "slug": "sahmaschools",
  "titleAr": "مجموعة سهما للتعليم والتدريب",
  "titleEn": "Sahma Education & Training Group",
  "group": "شركات وخدمات",
  "sectorAr": "التعليم",
  "descAr": "طريق أقصر من الاهتمام إلى التسجيل.",
  "accent": "#95b3d4",
  "domain": "sahmaschools.com",
  "caseUrl": "https://puiux.com/work/sahmaschools/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/sahmaschools-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع مجموعة سهما للتعليم والتدريب"
 },
 {
  "slug": "drizoro",
  "titleAr": "درايزورو السعودية",
  "titleEn": "Drizoro Saudi Arabia",
  "group": "عقارات وبناء",
  "sectorAr": "كيماويات البناء",
  "descAr": "من المشكلة في الموقع إلى المنتج المناسب.",
  "accent": "#dc2626",
  "domain": "drizoro.puiux.org",
  "caseUrl": "https://puiux.com/work/drizoro/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/drizoro-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع درايزورو السعودية"
 },
 {
  "slug": "rayanmufti",
  "titleAr": "شركة ذا سُمِت أوف جاستس للمحاماة",
  "titleEn": "The Summit of Justice Law Firm",
  "group": "قانون",
  "sectorAr": "المحاماة والاستشارات القانونية",
  "descAr": "طريق واضح من الزيارة إلى طلب الاستشارة",
  "accent": "#243143",
  "domain": "rayanmufti.com",
  "caseUrl": "https://puiux.com/work/rayanmufti/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/rayanmufti-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع شركة ذا سُمِت أوف جاستس للمحاماة"
 },
 {
  "slug": "sullaee",
  "titleAr": "جمعية الدعوة بالسلي",
  "titleEn": "Da'wah Association in Al-Sulay",
  "group": "شركات وخدمات",
  "sectorAr": "القطاع غير الربحي",
  "descAr": "شفافية الجمعية أمام داعميها في صفحة واحدة",
  "accent": "#337366",
  "domain": "sullaee.com",
  "caseUrl": "https://puiux.com/work/sullaee/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/sullaee-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع جمعية الدعوة بالسلي"
 },
 {
  "slug": "albayadcleaning",
  "titleAr": "أساس البياض",
  "titleEn": "Asas Al-Bayad",
  "group": "شركات وخدمات",
  "sectorAr": "خدمات التنظيف والصيانة",
  "descAr": "من البحث عن خدمة تنظيف إلى حجز مؤكد",
  "accent": "#00bddd",
  "domain": "albayadcleaning.com",
  "caseUrl": "https://puiux.com/work/albayadcleaning/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/albayadcleaning-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع أساس البياض"
 },
 {
  "slug": "coral",
  "titleAr": "كورال للاستشارات وتطوير الأعمال",
  "titleEn": "Coral Consulting & Business Development",
  "group": "شركات وخدمات",
  "sectorAr": "الاستشارات الإدارية",
  "descAr": "من فهم الخدمة إلى طلب الاستشارة مباشرة",
  "accent": "#1e3c49",
  "domain": "coral.com.sa",
  "caseUrl": "https://puiux.com/work/coral/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/coral-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع كورال للاستشارات وتطوير الأعمال"
 },
 {
  "slug": "sidq",
  "titleAr": "صدق",
  "titleEn": "Sidq",
  "group": "تجارة إلكترونية",
  "sectorAr": "الاستشارات الهندسية والتصميم",
  "descAr": "أعمال هندسية متنوعة في واجهة واحدة منظمة",
  "accent": "#bd9c6e",
  "domain": "sidq.com.sa",
  "caseUrl": "https://puiux.com/work/sidq/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/sidq-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع صدق"
 },
 {
  "slug": "rmcon",
  "titleAr": "آر إم كون",
  "titleEn": "RM Con",
  "group": "عقارات وبناء",
  "sectorAr": "المقاولات والإنشاءات",
  "descAr": "مقاولات موثوقة تبدأ من صفحة واضحة",
  "accent": "#306ba4",
  "domain": "rmcon.sa",
  "caseUrl": "https://puiux.com/work/rmcon/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/rmcon-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع آر إم كون"
 },
 {
  "slug": "alenaya",
  "titleAr": "شركة العناية",
  "titleEn": "Al-Enaya Company",
  "group": "شركات وخدمات",
  "sectorAr": "خدمات المرافق والتنظيف المتخصص",
  "descAr": "منشآت نظيفة بمعايير تُرى قبل أن تُطلب.",
  "accent": "#42b88e",
  "domain": "alenaya.puiux.org",
  "caseUrl": "https://puiux.com/work/alenaya/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/alenaya-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع شركة العناية"
 },
 {
  "slug": "alhaqbanilawyers",
  "titleAr": "شركة سعد بن عبدالعزيز الحقباني للمحاماة والاستشارات القانونية",
  "titleEn": "Saad bin Abdulaziz Al-Haqbani Law Firm",
  "group": "قانون",
  "sectorAr": "المحاماة والاستشارات القانونية",
  "descAr": "خبرة قضائية تجد طريقها إلى موكّليها.",
  "accent": "#166051",
  "domain": "alhaqbanilawyers.puiux.org",
  "caseUrl": "https://puiux.com/work/alhaqbanilawyers/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/alhaqbanilawyers-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع شركة سعد بن عبدالعزيز الحقباني للمحاماة والاستشارات القانونية"
 },
 {
  "slug": "banat",
  "titleAr": "بنات الأحبة",
  "titleEn": "Banat Al-Ahbah",
  "group": "شركات وخدمات",
  "sectorAr": "منصات مجتمعية وعائلية",
  "descAr": "سجل العائلة في مكان واحد وآمن.",
  "accent": "#6b2c34",
  "domain": "banat.puiux.org",
  "caseUrl": "https://puiux.com/work/banat/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/banat-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع بنات الأحبة"
 },
 {
  "slug": "hira",
  "titleAr": "حي حراء الثقافي",
  "titleEn": "Hira Cultural District",
  "group": "شركات وخدمات",
  "sectorAr": "السياحة الثقافية والدينية",
  "descAr": "تجربة تليق بمكان نزول الوحي.",
  "accent": "#452e21",
  "domain": "design.hira.puiux.org",
  "caseUrl": "https://puiux.com/work/hira/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/hira-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع حي حراء الثقافي"
 },
 {
  "slug": "mft",
  "titleAr": "إم إف تي",
  "titleEn": "MFT",
  "group": "عقارات وبناء",
  "sectorAr": "التصميم الداخلي والمقاولات",
  "descAr": "مساحات عمل تُعرف من أول نظرة.",
  "accent": "#402f1e",
  "domain": "design.mft.puiux.org",
  "caseUrl": "https://puiux.com/work/mft/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/mft-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع MFT"
 },
 {
  "slug": "fawq",
  "titleAr": "فوق",
  "titleEn": "Fawq",
  "group": "تعليم",
  "sectorAr": "تعليم إلكتروني",
  "descAr": "منصة تعليمية متكاملة، على الويب والجوال.",
  "accent": "#184a49",
  "domain": "fawq.puiux.org",
  "caseUrl": "https://puiux.com/work/fawq/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/fawq-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع فوق"
 },
 {
  "slug": "goahead",
  "titleAr": "إستمر للخدمات اللوجستية",
  "titleEn": "Istamir Logistics",
  "group": "صناعة وتصدير",
  "sectorAr": "خدمات لوجستية وتخزين مبرد",
  "descAr": "سلسلة تبريد واضحة من الميناء حتى المستودع",
  "accent": "#5a311a",
  "domain": "goahead.puiux.org",
  "caseUrl": "https://puiux.com/work/goahead/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/goahead-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع إستمر للخدمات اللوجستية"
 },
 {
  "slug": "rass-association",
  "titleAr": "جمعية البر الأهلية بمحافظة الرس",
  "titleEn": "Al-Birr Charity Association in Al-Rass",
  "group": "تجارة إلكترونية",
  "sectorAr": "قطاع غير ربحي",
  "descAr": "تبرع أسهل، وثقة أوضح بين الجمعية وداعميها",
  "accent": "#ab9057",
  "domain": "per-alras.org.sa",
  "caseUrl": "https://puiux.com/work/rass-association/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/rass-association-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع جمعية البر الأهلية بمحافظة الرس"
 },
 {
  "slug": "lighting-poles",
  "titleAr": "أعمدة الإضاءة",
  "titleEn": "Lighting Poles",
  "group": "شركات وخدمات",
  "sectorAr": "الصناعة والإنارة",
  "descAr": "إنارة المشاريع تبدأ من مورد واضح",
  "accent": "#3224af",
  "domain": "design.lighting-poles.puiux.org",
  "caseUrl": "https://puiux.com/work/lighting-poles/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/lighting-poles-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع أعمدة الإضاءة"
 },
 {
  "slug": "alsiham",
  "titleAr": "السهام",
  "titleEn": "Al-Siham",
  "group": "عقارات وبناء",
  "sectorAr": "المقاولات الكهروميكانيكية",
  "descAr": "قدرة فنية ظاهرة أمام الجهات الكبرى",
  "accent": "#452922",
  "domain": "design.alsiham.puiux.org",
  "caseUrl": "https://puiux.com/work/alsiham/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/alsiham-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع السهام"
 },
 {
  "slug": "dev",
  "titleAr": "أونت",
  "titleEn": "Ont",
  "group": "شركات وخدمات",
  "sectorAr": "الاتصالات",
  "descAr": "اتصال فوري أينما سافرت",
  "accent": "#ff9233",
  "domain": "dev.puiux.org",
  "caseUrl": "https://puiux.com/work/dev/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/dev-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع أونت"
 },
 {
  "slug": "mediation",
  "titleAr": "شركة الوساطة الدولية",
  "titleEn": "International Mediation Company",
  "group": "شركات وخدمات",
  "sectorAr": "الوساطة المالية والتجارية",
  "descAr": "خدمات مالية معقدة بلغة يفهمها المستثمر",
  "accent": "#cb9a52",
  "domain": "intmediationco.com",
  "caseUrl": "https://puiux.com/work/mediation/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/mediation-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع شركة الوساطة الدولية"
 },
 {
  "slug": "riyadati",
  "titleAr": "رياضتي",
  "titleEn": "Riyadati",
  "group": "صحة ومجتمع",
  "sectorAr": "الصحة واللياقة",
  "descAr": "طريق أسهل نحو نمط حياة صحي",
  "accent": "#1900fe",
  "domain": "riyadati.puiux.org",
  "caseUrl": "https://puiux.com/work/riyadati/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/riyadati-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع رياضتي"
 },
 {
  "slug": "al-qalaa",
  "titleAr": "القلاع للمقاولات العامة",
  "titleEn": "Al-Qalaa General Contracting",
  "group": "عقارات وبناء",
  "sectorAr": "المقاولات العامة",
  "descAr": "سجل مشاريع يتحدث عن الخبرة",
  "accent": "#f37021",
  "domain": "al-qalaa.puiux.org",
  "caseUrl": "https://puiux.com/work/al-qalaa/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/al-qalaa-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع القلاع للمقاولات العامة"
 },
 {
  "slug": "sarhed-elqbda",
  "titleAr": "أبو سرهد القابضة",
  "titleEn": "Abu Sarhad Holding",
  "group": "شركات وخدمات",
  "sectorAr": "الشركات القابضة",
  "descAr": "هوية واحدة تجمع قطاعات متعددة",
  "accent": "#213c7e",
  "domain": "sarhed-elqbda.puiux.org",
  "caseUrl": "https://puiux.com/work/sarhed-elqbda/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/sarhed-elqbda-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع أبو سرهد القابضة"
 },
 {
  "slug": "jaffa",
  "titleAr": "يافا",
  "titleEn": "Jaffa",
  "group": "شركات وخدمات",
  "sectorAr": "الصناعة والمعدات",
  "descAr": "معدات صناعية واضحة لمن يقرر الشراء.",
  "accent": "#839a36",
  "domain": "design.jaffa.puiux.org",
  "caseUrl": "https://puiux.com/work/jaffa/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/jaffa-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع Jaffa"
 },
 {
  "slug": "muheel",
  "titleAr": "مهيل",
  "titleEn": "Muheel",
  "group": "شركات وخدمات",
  "sectorAr": "إدارة المرافق",
  "descAr": "حضور مؤسسي يليق بعقود المرافق الكبرى.",
  "accent": "#f99e22",
  "domain": "design.muheel.puiux.org",
  "caseUrl": "https://puiux.com/work/muheel/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/muheel-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع مهيل"
 },
 {
  "slug": "pcbs",
  "titleAr": "بي سي بي إس",
  "titleEn": "PCBS",
  "group": "عقارات وبناء",
  "sectorAr": "البناء والخرسانة مسبقة الصب",
  "descAr": "سجل مشاريع يتحدث عن قدرة التنفيذ.",
  "accent": "#b39e0b",
  "domain": "pcbs.puiux.org",
  "caseUrl": "https://puiux.com/work/pcbs/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/pcbs-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع PCBS"
 },
 {
  "slug": "semo",
  "titleAr": "جمعية سمو لتعزيز القيم",
  "titleEn": "Sumu Association for Promoting Values",
  "group": "شركات وخدمات",
  "sectorAr": "القطاع غير الربحي",
  "descAr": "رسالة قيمية تجد من يشارك فيها.",
  "accent": "#005076",
  "domain": "semo.puiux.org",
  "caseUrl": "https://puiux.com/work/semo/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/semo-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع جمعية سمو لتعزيز القيم"
 },
 {
  "slug": "shayek",
  "titleAr": "شيّك",
  "titleEn": "Shayek",
  "group": "شركات وخدمات",
  "sectorAr": "التجارة والتوصيل",
  "descAr": "موقع واحد يجذب العميل والتاجر والسائق",
  "accent": "#039789",
  "domain": "shayek.puiux.org",
  "caseUrl": "https://puiux.com/work/shayek/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/shayek-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع شيّك"
 },
 {
  "slug": "neurofy",
  "titleAr": "نيوروفاي",
  "titleEn": "Neurofy",
  "group": "صحة ومجتمع",
  "sectorAr": "التقنية الصحية",
  "descAr": "تقنية معقدة تُشرح بلغة يفهمها المريض",
  "accent": "#8b5eab",
  "domain": "neurofy.puiux.org",
  "caseUrl": "https://puiux.com/work/neurofy/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/neurofy-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع نيوروفاي"
 },
 {
  "slug": "fawzya-alhoushan-design",
  "titleAr": "فوزية الحوشان",
  "titleEn": "Fawzia Al-Houshan",
  "group": "شركات وخدمات",
  "sectorAr": "التدريب والكوتشينغ",
  "descAr": "حضور شخصي يفتح باب الأفراد والشركات",
  "accent": "#522852",
  "domain": "design.fawzya-elhoushan.puiux.org",
  "caseUrl": "https://puiux.com/work/fawzya-alhoushan-design/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/fawzya-alhoushan-design-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع فوزية الحوشان"
 },
 {
  "slug": "tajriba",
  "titleAr": "تجربة للاستشارات الإدارية",
  "titleEn": "Tajriba Management Consulting",
  "group": "شركات وخدمات",
  "sectorAr": "الاستشارات الإدارية",
  "descAr": "خبرة تجربة العملاء معروضة بأدلة واضحة",
  "accent": "#d8bb71",
  "domain": "tajriba.puiux.org",
  "caseUrl": "https://puiux.com/work/tajriba/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/tajriba-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع تجربة للاستشارات الإدارية"
 },
 {
  "slug": "masarat",
  "titleAr": "مكتب المسارات الرائدة للاستشارات الإدارية",
  "titleEn": "Leading Pathways Management Consulting Office",
  "group": "شركات وخدمات",
  "sectorAr": "الاستشارات الإدارية للقطاع غير الربحي",
  "descAr": "شريك استشاري واضح للقطاع غير الربحي",
  "accent": "#88a842",
  "domain": "design.masarat.puiux.org",
  "caseUrl": "https://puiux.com/work/masarat/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/masarat-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع مكتب المسارات الرائدة للاستشارات الإدارية"
 },
 {
  "slug": "emc",
  "titleAr": "علم ومعمار للمقاولات",
  "titleEn": "Ilm & Mimar Contracting",
  "group": "عقارات وبناء",
  "sectorAr": "المقاولات العامة",
  "descAr": "سجل تنفيذ واضح يقنع قبل أول اجتماع",
  "accent": "#ff934b",
  "domain": "emc.puiux.org",
  "caseUrl": "https://puiux.com/work/emc/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/emc-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع علم ومعمار للمقاولات"
 },
 {
  "slug": "manazel",
  "titleAr": "منازل العقارية",
  "titleEn": "Manazel Real Estate",
  "group": "عقارات وبناء",
  "sectorAr": "التطوير العقاري",
  "descAr": "من البحث عن منزل إلى التواصل بسهولة",
  "accent": "#b81f24",
  "domain": "manazil-sa.com",
  "caseUrl": "https://puiux.com/work/manazel/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/manazel-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع منازل العقارية"
 },
 {
  "slug": "saleh",
  "titleAr": "الصالح والسهلي ومشاركوهم للمحاماة",
  "titleEn": "Al-Saleh, Al-Sahli & Partners Law Firm",
  "group": "قانون",
  "sectorAr": "المحاماة والاستشارات القانونية",
  "descAr": "حضور قانوني رصين يبني الثقة",
  "accent": "#473c19",
  "domain": "saleh.puiux.org",
  "caseUrl": "https://puiux.com/work/saleh/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/saleh-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع الصالح والسهلي ومشاركوهم للمحاماة"
 },
 {
  "slug": "impact",
  "titleAr": "صنّاع الأثر",
  "titleEn": "Athar Makers",
  "group": "شركات وخدمات",
  "sectorAr": "الاستشارات الإدارية",
  "descAr": "خدمات استشارية واضحة تصنع أثرًا ملموسًا",
  "accent": "#15144e",
  "domain": "impact.puiux.org",
  "caseUrl": "https://puiux.com/work/impact/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/impact-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع صنّاع الأثر"
 },
 {
  "slug": "fundicum",
  "titleAr": "فنديكوم",
  "titleEn": "Fundicum",
  "group": "تطبيقات",
  "sectorAr": "السياحة وحجوزات الإقامة",
  "descAr": "إقامتك القادمة على بُعد بحث واحد.",
  "accent": "#5b4a7c",
  "domain": "fundicum.com",
  "caseUrl": "https://puiux.com/work/fundicum/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/fundicum-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع فنديكوم"
 },
 {
  "slug": "dar-mousa",
  "titleAr": "دار موسى للاستثمار التجاري والعقاري",
  "titleEn": "Dar Mousa Commercial & Real Estate Investment",
  "group": "شركات وخدمات",
  "sectorAr": "الاستثمار العائلي والتطوير العقاري",
  "descAr": "استثمار عائلي يُقرأ بثقة من أول صفحة.",
  "accent": "#0e3e23",
  "domain": "dar-mousa.puiux.org",
  "caseUrl": "https://puiux.com/work/dar-mousa/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/dar-mousa-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع دار موسى للاستثمار التجاري والعقاري"
 },
 {
  "slug": "tajseem",
  "titleAr": "تجسيم للتصميم والهندسة",
  "titleEn": "Tajseem Design & Engineering",
  "group": "عقارات وبناء",
  "sectorAr": "المجسمات المعمارية والنماذج الهندسية",
  "descAr": "مجسمات معمارية بمقاييس دقيقة.",
  "accent": "#463556",
  "domain": "beta.puiux.org",
  "caseUrl": "https://puiux.com/work/tajseem/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/tajseem-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع تجسيم للتصميم والهندسة"
 },
 {
  "slug": "solid-olympic",
  "titleAr": "الأكاديمية الأولمبية السعودية",
  "titleEn": "Saudi Olympic Academy",
  "group": "صحة ومجتمع",
  "sectorAr": "التعليم والثقافة الأولمبية",
  "descAr": "الثقافة الأولمبية، في متناول كل مهتم.",
  "accent": "#4e6646",
  "domain": "demo.puiux.org",
  "caseUrl": "https://puiux.com/work/solid-olympic/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/solid-olympic-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع الأكاديمية الأولمبية السعودية"
 },
 {
  "slug": "eventa",
  "titleAr": "إيفينتا",
  "titleEn": "Eventa",
  "group": "شركات وخدمات",
  "sectorAr": "الفعاليات وأجنحة المعارض والمؤتمرات",
  "descAr": "أجنحة معارض تُرى قبل أن تُبنى.",
  "accent": "#dd622f",
  "domain": "eventa.com.sa",
  "caseUrl": "https://puiux.com/work/eventa/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/eventa-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع إيفينتا"
 },
 {
  "slug": "shamah",
  "titleAr": "شمعة التوحد",
  "titleEn": "Autism Candle",
  "group": "صحة ومجتمع",
  "sectorAr": "التأهيل وخدمات التوحد",
  "descAr": "رحلة تمكين تبدأ من أول تواصل.",
  "accent": "#0f3842",
  "domain": "centers.shamah.org.sa",
  "caseUrl": "https://puiux.com/work/shamah/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/shamah-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع شمعة التوحد"
 },
 {
  "slug": "alatifilaw",
  "titleAr": "شركة مسفر العاطفي للمحاماة والاستشارات القانونية",
  "titleEn": "Misfer Al-Atifi Law Firm",
  "group": "قانون",
  "sectorAr": "المحاماة والاستشارات القانونية",
  "descAr": "شراكة في القرار، لا مجرد تمثيل.",
  "accent": "#843f25",
  "domain": "alatifilaw.sa",
  "caseUrl": "https://puiux.com/work/alatifilaw/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/alatifilaw-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع شركة مسفر العاطفي للمحاماة والاستشارات القانونية"
 },
 {
  "slug": "quranalrass",
  "titleAr": "متجر جمعية تحفيظ القرآن بالرس",
  "titleEn": "Al-Rass Quran Memorization Association Store",
  "group": "تجارة إلكترونية",
  "sectorAr": "القطاع غير الربحي",
  "descAr": "كل وجوه الخير للجمعية في متجر واحد.",
  "accent": "#9bc8a7",
  "domain": "charity.puiux.org",
  "caseUrl": "https://puiux.com/work/quranalrass/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/quranalrass-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع متجر جمعية تحفيظ القرآن بالرس"
 },
 {
  "slug": "moreq",
  "titleAr": "مورق",
  "titleEn": "Moreq",
  "group": "تجارة إلكترونية",
  "sectorAr": "القرطاسية والمكتبات",
  "descAr": "أدوات الدراسة كلها، بضغطة زر.",
  "accent": "#034d5b",
  "domain": "moreq.puiux.org",
  "caseUrl": "https://puiux.com/work/moreq/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/moreq-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع مورق"
 },
 {
  "slug": "frame",
  "titleAr": "متجر فريم",
  "titleEn": "Frame Store",
  "group": "تجارة إلكترونية",
  "sectorAr": "الفن واللوحات الجدارية",
  "descAr": "لوحتك بالمقاس والإطار الذي تختاره.",
  "accent": "#f5ae46",
  "domain": "frame.puiux.org",
  "caseUrl": "https://puiux.com/work/frame/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/frame-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع متجر فريم"
 },
 {
  "slug": "bride2b",
  "titleAr": "برايد تو بي",
  "titleEn": "Bride2B",
  "group": "شركات وخدمات",
  "sectorAr": "خدمات الأعراس",
  "descAr": "يوم الزفاف كله، في منصة واحدة.",
  "accent": "#684f3b",
  "domain": "bride2b.puiux.org",
  "caseUrl": "https://puiux.com/work/bride2b/",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/bride2b-c.webp",
  "phones": null,
  "alt": "الصفحة الرئيسية لموقع Bride2B"
 }
];

export const archiveWorks: ArchiveWork[] = [
 {
  "titleAr": "ماكس ستور",
  "titleEn": "Max Store",
  "sectorAr": "تجارة إلكترونية",
  "sectorEn": "E-commerce",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/maxstoore-com.webp"
 },
 {
  "titleAr": "بيت الحكمة",
  "titleEn": "Bayt Al-Hikma",
  "sectorAr": "أخرى",
  "sectorEn": "Other",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/bayt-elhikma-com.webp"
 },
 {
  "titleAr": "إمباكت بارتنرز",
  "titleEn": "Impact Partners",
  "sectorAr": "استشارات ومال",
  "sectorEn": "Consulting & Finance",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/impactp-consulting.webp"
 },
 {
  "titleAr": "الحرم للمقاولات",
  "titleEn": "Al-Haram Contracting",
  "sectorAr": "مقاولات وبناء",
  "sectorEn": "Contracting & Construction",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/alarmco-sa.webp"
 },
 {
  "titleAr": "قمم البناء",
  "titleEn": "Qimam Al-Binaa",
  "sectorAr": "مقاولات وبناء",
  "sectorEn": "Contracting & Construction",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/ctops-com-sa.webp"
 },
 {
  "titleAr": "ريد سي",
  "titleEn": "Red Sea",
  "sectorAr": "مقاولات وبناء",
  "sectorEn": "Contracting & Construction",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/redsea-com-sa.webp"
 },
 {
  "titleAr": "متجر جمعية رسوخ",
  "titleEn": "Rosokh Association Store",
  "sectorAr": "جمعيات وجهات",
  "sectorEn": "Non-profits & Entities",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/store-rosokh-org-sa.webp"
 },
 {
  "titleAr": "تطبيق العزبة",
  "titleEn": "Al-Azbah App",
  "sectorAr": "تجارة إلكترونية",
  "sectorEn": "E-commerce",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/al-azbah-vercel-app.webp"
 },
 {
  "titleAr": "ميثودز",
  "titleEn": "Methods",
  "sectorAr": "مطاعم وأغذية",
  "sectorEn": "Food & Beverage",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-methods-puiux-org.webp"
 },
 {
  "titleAr": "شركة سعد عبد العزيز الحقباني",
  "titleEn": "Saad Abdulaziz Al-Haqbani Company",
  "sectorAr": "محاماة",
  "sectorEn": "Legal",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/alhaqbani-puiux-org.webp"
 },
 {
  "titleAr": "بداية",
  "titleEn": "Bidaya",
  "sectorAr": "صحة",
  "sectorEn": "Health",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/bdaya-puiux-org.webp"
 },
 {
  "titleAr": "دار موسى",
  "titleEn": "Dar Mousa",
  "sectorAr": "تطوير عقاري",
  "sectorEn": "Real Estate",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/dar-mousa-puiux-org.webp"
 },
 {
  "titleAr": "شركة دارين العقارية",
  "titleEn": "Darin Real Estate",
  "sectorAr": "تطوير عقاري",
  "sectorEn": "Real Estate",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/darin-puiux-org.webp"
 },
 {
  "titleAr": "الحسام",
  "titleEn": "Al-Hussam",
  "sectorAr": "شركات وخدمات",
  "sectorEn": "Corporate & Services",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-alhasam-puiux-org.webp"
 },
 {
  "titleAr": "إل بي سي",
  "titleEn": "LPC",
  "sectorAr": "صناعة ولوجستيات",
  "sectorEn": "Industry & Logistics",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-lpc-puiux-org.webp"
 },
 {
  "titleAr": "شركة مطوفي حجاج إيران",
  "titleEn": "Motawifi Iran Pilgrims Company",
  "sectorAr": "فعاليات وسياحة",
  "sectorEn": "Events & Tourism",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-motwofi-puiux-org.webp"
 },
 {
  "titleAr": "أبو سرهد للخيام",
  "titleEn": "Abu Sarhad Tents",
  "sectorAr": "مقاولات وبناء",
  "sectorEn": "Contracting & Construction",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-sarhed-heaim-puiux-org.webp"
 },
 {
  "titleAr": "المستشفى التخصصي",
  "titleEn": "Specialized Hospital",
  "sectorAr": "صحة",
  "sectorEn": "Health",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-specialized-hospital-puiux-org.webp"
 },
 {
  "titleAr": "الصافية",
  "titleEn": "Al-Safia",
  "sectorAr": "فعاليات وسياحة",
  "sectorEn": "Events & Tourism",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/el-safia-puiux-org.webp"
 },
 {
  "titleAr": "القلعة",
  "titleEn": "Al-Qalaa",
  "sectorAr": "مقاولات وبناء",
  "sectorEn": "Contracting & Construction",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/elqlaa-puiux-org.webp"
 },
 {
  "titleAr": "إيفينتا",
  "titleEn": "Eventa",
  "sectorAr": "فعاليات وسياحة",
  "sectorEn": "Events & Tourism",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/eventa-puiux-org.webp"
 },
 {
  "titleAr": "ازار",
  "titleEn": "Ezar",
  "sectorAr": "مطاعم وأغذية",
  "sectorEn": "Food & Beverage",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/ezar-puiux-org.webp"
 },
 {
  "titleAr": "غيم للتسويق العقاري",
  "titleEn": "Ghaim Real Estate Marketing",
  "sectorAr": "تطوير عقاري",
  "sectorEn": "Real Estate",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/ghiam-puiux-org.webp"
 },
 {
  "titleAr": "بروفيجنز",
  "titleEn": "Provisionz",
  "sectorAr": "مطاعم وأغذية",
  "sectorEn": "Food & Beverage",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/prov-puiux-org.webp"
 },
 {
  "titleAr": "شركة رمات",
  "titleEn": "Ramat Company",
  "sectorAr": "صناعة ولوجستيات",
  "sectorEn": "Industry & Logistics",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/ramat-puiux-org.webp"
 },
 {
  "titleAr": "منصة آل ملحم",
  "titleEn": "Al Melhem Platform",
  "sectorAr": "أخرى",
  "sectorEn": "Other",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/al-milhem-frontend-vercel-app.webp"
 },
 {
  "titleAr": "بر ينبع",
  "titleEn": "Bir Yanbu",
  "sectorAr": "جمعيات وجهات",
  "sectorEn": "Non-profits & Entities",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-bir-yanbu-puiux-org.webp"
 },
 {
  "titleAr": "سمو ماس للمقاولات العامة",
  "titleEn": "SMO Mas General Contracting",
  "sectorAr": "مقاولات وبناء",
  "sectorEn": "Contracting & Construction",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/smo-mas-puiux-org.webp"
 },
 {
  "titleAr": "شركة المطالبة لتحصيل الديون",
  "titleEn": "Al-Mutalaba Debt Collection",
  "sectorAr": "استشارات ومال",
  "sectorEn": "Consulting & Finance",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/almotalbah-puiux-org.webp"
 },
 {
  "titleAr": "اركال",
  "titleEn": "Arkal",
  "sectorAr": "مقاولات وبناء",
  "sectorEn": "Contracting & Construction",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/arkal-puiux-org.webp"
 },
 {
  "titleAr": "كانا",
  "titleEn": "Canna",
  "sectorAr": "مقاولات وبناء",
  "sectorEn": "Contracting & Construction",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/canna-puiux-org.webp"
 },
 {
  "titleAr": "آسيا نوفا ميتال",
  "titleEn": "Aasia Nova Metal",
  "sectorAr": "صناعة ولوجستيات",
  "sectorEn": "Industry & Logistics",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-aasianovametal-puiux-org.webp"
 },
 {
  "titleAr": "شركة الوادي الدولي",
  "titleEn": "Al-Wadi International Company",
  "sectorAr": "منصات تقنية",
  "sectorEn": "Tech Platforms",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-elwady-puiux-org.webp"
 },
 {
  "titleAr": "روعة الألوان",
  "titleEn": "Rawaa Al-Alwan",
  "sectorAr": "صناعة ولوجستيات",
  "sectorEn": "Industry & Logistics",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-rawaa-alwan-puiux-org.webp"
 },
 {
  "titleAr": "تيراز",
  "titleEn": "Teraz",
  "sectorAr": "تجارة إلكترونية",
  "sectorEn": "E-commerce",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/design-teraz-puiux-org.webp"
 },
 {
  "titleAr": "احتزم",
  "titleEn": "Ehtazm",
  "sectorAr": "تطوير عقاري",
  "sectorEn": "Real Estate",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/ehtazm-landing-puiux-org.webp"
 },
 {
  "titleAr": "معهد الابعاد الخضراء",
  "titleEn": "Green Dimensions Institute",
  "sectorAr": "تعليم",
  "sectorEn": "Education",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/green-dinemtions-puiux-org.webp"
 },
 {
  "titleAr": "شركة حسين لتأجير السيارات",
  "titleEn": "Hussain Car Rental",
  "sectorAr": "أخرى",
  "sectorEn": "Other",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/hussain-puiux-org.webp"
 },
 {
  "titleAr": "مطاعم ماديلي",
  "titleEn": "Madeli Restaurants",
  "sectorAr": "مطاعم وأغذية",
  "sectorEn": "Food & Beverage",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/madeli-puiux-org.webp"
 },
 {
  "titleAr": "نحت الأصول",
  "titleEn": "Naht Al-Osool",
  "sectorAr": "تطوير عقاري",
  "sectorEn": "Real Estate",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/naht-elosol-puiux-org.webp"
 },
 {
  "titleAr": "معهد تطور",
  "titleEn": "Tatawor Institute",
  "sectorAr": "تعليم",
  "sectorEn": "Education",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/tatawor-puiux-org.webp"
 },
 {
  "titleAr": "ياستدم",
  "titleEn": "Yastdem",
  "sectorAr": "تطوير عقاري",
  "sectorEn": "Real Estate",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/yastdem-puiux-org.webp"
 },
 {
  "titleAr": "إيه إم إس",
  "titleEn": "AMS",
  "sectorAr": "تعليم",
  "sectorEn": "Education",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/ams-puiux-org.webp"
 },
 {
  "titleAr": "دلتا كو المحدودة",
  "titleEn": "Delta Co Limited",
  "sectorAr": "شركات وخدمات",
  "sectorEn": "Corporate & Services",
  "cover": "https://puiux.com/wp-content/mu-plugins/puiux-home-v6/work/arch/delta-puiux-org.webp"
 }
];
